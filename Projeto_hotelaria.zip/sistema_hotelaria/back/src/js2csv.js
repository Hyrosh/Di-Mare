const { createReadStream, createWriteStream } = require('fs');
const { Transform } = require('json2csv');
 
const fields = ['field1', 'field2', 'field3'];
const opts = { fields };
const transformOpts = { highWaterMark: 16384, encoding: 'utf-8' };
 
const input = createReadStream("./clientes.csv", { encoding: 'utf8' });
const output = createWriteStream("./clientes.csv", { encoding: 'utf8' });
const json2csv = new Transform(opts, transformOpts);
 
const processor = input.pipe(json2csv).pipe(output);
 
// You can also listen for events on the conversion and see how the header or the lines are coming out.
json2csv
  .on('header', header => console.log(header))
  .on('line', line => console.log(line))
  .on('error', err => console.log(err));