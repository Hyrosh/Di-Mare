const server = require('./app');

server.listen(3333, () => console.log("Servidor rodando..."));