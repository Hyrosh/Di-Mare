<?php
session_start();
include("php/conexao.php");
if(!empty($_SESSION["email"])){
$email = $_SESSION['email'];
$cone = new conecta();
$consulta = $cone->pdo->prepare("SELECT * FROM funcionarios WHERE email = :email");
$consulta->bindValue(":email", $email);
$consulta->execute();
$administrador=$consulta->fetch(PDO::FETCH_ASSOC);

$id_reserva = $_POST["id_reserva"];

$consulta_reserva = $cone->pdo->prepare(
    "
        SELECT
            reservas.*,
            DATE_FORMAT(reservas.dia, '%d/%m/%Y') as dia_entrada,
            DATE_FORMAT(reservas.diasaida, '%d/%m/%Y') as dia_saida,
            DATE_FORMAT(reservas.horarioinicial, '%H:%i') as hora_entrada,
            DATE_FORMAT(reservas.horariofinal, '%H:%i') as hora_saida,
            clientes.id as id_cliente,
            clientes.nomecliente,
            tipoquartos.id as id_quarto,
            tipoquartos.precoquarto as valor_diaria,
            DATEDIFF(diasaida,dia) as diarias,
            DATEDIFF(diasaida,dia) * tipoquartos.precoquarto as valor_total
        FROM
            reservas INNER JOIN clientes ON clientes.id = reservas.clientechave
        INNER JOIN tipoquartos ON tipoquartos.id = reservas.tipoquartochave
        WHERE
            reservas.id = $id_reserva
    "
);
$consulta_reserva->bindValue(":id", $id_reserva);
$consulta_reserva->execute();
$dados_reserva=$consulta_reserva->fetch(PDO::FETCH_ASSOC);

echo '<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>reservas | Sistema de reservas</title>
        <link href="estilos/clientes-estilo.css"  rel="stylesheet"/>
        <link href="estilos/padrao_estilo.css" rel="stylesheet" />
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <script src="javascript/menu.js"></script>
        <script src="javascript/jquery.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=BioRhyme" rel="stylesheet">
        <link rel="icon" href="img/icone.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <meta name="robots" content="noindex, nofollow">
        <script>
            $(window).load(function(){
                $("body").css("display","block");
            });
        </script>
        <script>
            $(function() {
                var nav = $("#navegacao");
                $(window).scroll(function () {
                    if($(this).scrollTop() > 0) {
                        nav.addClass("menu-fixo");
                    } else {
                        nav.removeClass("menu-fixo");
                    }
                });
            });
        </script>

        <style>
            h1 {
                text-align: center;
                font-size: 3em;
            }

            table {
                margin: 0 auto;
            }

            fieldset {
                padding: 10px;
            }
        </style>
    </head>
    <body onload="carrega()">
        <section id="fundo">
            <header id="header">
                <figure>
                    <figcaption>
                        <nav id="navegacao">
                            <a href="index"><img src="img/logo.png" id="logo" alt="Sistema de reservas" title="Sistema de reservas"></a>
                            <ul>';
                            if($administrador["tiririca"]== "admin") {
                                echo '<a href="cadastro/funcionario" title="Cadastro de Funcionário"><li>Cadastro de <br>Funcionário</li></a>';
                            } else {
                                echo '<a href="chamado/reserva" title="Cadastro de Reserva"><li>Cadastro de <br>Reserva</li></a>';
                            }
                            echo '<a href="cadastro/quarto" title="Cadastro de Quarto"><li>Cadastro de <br>Quarto</li></a>
                            </ul>
                            </div>
                                <a href="#" onclick=\'carrega_menu("menu_mobile")\'><img src="img/menu-icone.png" id="icone-menu" alt="Menu"></a>
                            <ul id="menu_mobile">
                                <a href="cadastro/pagseguro" title="Check Out"><li>Check <br>Out</li></a>';
                            if($administrador["tiririca"]== "admin"){
                                echo '<a href="cadastro/funcionario" title="Cadastro de Funcionário"><li>Cadastro de Funcionário</li></a>';
                            }else{
                                echo '<a href="chamado/atendimento" title="Abertura de Chamado"><li>Abertura de Chamado</li></a>';
                            }
                            echo '<a href="cadastro/quarto" title="Cadastro de Quarto"><li>Cadastro de <br>Quarto</li></a>
                            </ul>';
                            if(empty(!$_SESSION["email"])) {
                                $nome = explode(" ",$administrador["nome"]);
                                print('<p class="login">Bem Vindo '.$nome[0].'</p><br>');
                                print('<a href="logout" class="sair">Sair</a>');
                            }
                        echo '</nav>
                    </figcaption>
                </figure>
            </header>
            <section id="slide">
                <img src="img/imagem_fundo.jpg" class="imagem_fundo" title="Sistema de reservas" alt="Sistema de reservas">
                <img src="img/imagem_fundo-2.jpg" class="imagem_fundo2">
                <img src="img/imagem_fundo-3.jpg" class="imagem_fundo3">
            </section>
            <section class="todo">
                <section>
                    <h1>Check-Out</h1>
                    <table width="800px" cellspacing="4" cellspadding="3" align="center">
                        <tr>
                            <td width="200px">
                                Reserva N&deg;
                            </td>
                            <td>
                                <strong>'.$dados_reserva['numreserva'].'</strong>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Entrada / Saída
                            </td>
                            <td>
                                <strong>'.$dados_reserva['dia_entrada'].' '.$dados_reserva['hora_entrada'].' até '.$dados_reserva['dia_saida'].' '.$dados_reserva['hora_saida'].'</strong>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Diárias
                            </td>
                            <td>
                                <strong>R$ '.number_format($dados_reserva['diarias'], 2, ',', '.').'</strong>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Valor diária
                            </td>
                            <td>
                                <strong>R$ '.number_format($dados_reserva['valor_diaria'], 2, ',', '.').'</strong>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Valor total diárias
                            </td>
                            <td>
                                <strong>R$ '.number_format($dados_reserva['valor_total'], 2, ',', '.').'</strong>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <fieldset>
                                    <legend>Consumo</legend>
                                    <table width="100%" cellspacing="2">
                                        <tr>
                                            <td>
                                                Importar consumo
                                            </td>
                                            <td>
                                                <button>Carregar arquivo</button>
                                            </td>
                                        </tr>
                                    </table>
                                </fieldset>
                            </td>
                        </tr>
                    </table>
                </section>
            <footer>
                <img src="img/logo.png" alt="Sistema de reservas" title="Sistema de reservas">
                <p>© Sistema de reservas | Todos os direitos reservados.</p>
            </footer>
        </section>
    </body>
</html>';
}else{
echo '<meta http-equiv="refresh" content="0, url=login.php">';
}
?>