<?php
date_default_timezone_set('America/Sao_Paulo'); 

class config{
var $host = 'localhost';
var $usuario = 'root';
var $senha ='';
var $db = 'hotel';
}
?>